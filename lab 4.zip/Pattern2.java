/* 
 * Pattern - 02
 * 
 *  1
	10
	101
	1010
	10101 
	
 * */
package practical.no4;

public class Pattern2 {
	public static void main(String[] args) {
		int n = 5, row, col;
		for (row = 0; row <= n; row++) {
			for (col = 0; col <= row - 1; col++) {
				if (col % 2 == 0)
					System.out.print(1 + " ");
				else
					System.out.print(0 + " ");
			}
			System.out.println();
		}
	}
}
