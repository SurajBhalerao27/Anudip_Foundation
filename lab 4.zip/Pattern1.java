/*
 * Pattern - 01
 * 
 *  j ->
  i	1 0 1 0 1
  |	0 1 0 1 0
  v 1 0 1 0 1
	0 1 0 1 0
	1 0 1 0 1

 * */
package practical.no4;

public class Pattern1 {
	public static void main(String[] args) {

//		for (int i = 1; i <= 5; i++) {
//			for (int j = 1; j <= 5; j++) {
//				if (i == j || i + j == 5 + 1)/* ((i + j) + 1) / 2 == 3) */ {
//					System.out.print(1 + " ");
//				} else
//					System.out.print(0 + " ");
//			}
//			System.out.println();
//		}

		for (int i = 1; i <= 5; i++) {
			for (int j = 0; j < 5; j++) {
//				if (i % 2 == 0 || j % 2 == 0)
//					System.out.print(" " + 0);
//				else
//					System.out.print(" " + 1);
				System.out.print(((i + j) % 2) + " ");
			}
			System.out.println();
		}
	}
}