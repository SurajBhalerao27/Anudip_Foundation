/*
 * 2) Write a program to take a number from user. Check if the number is positive or negative.
 * */
package practicals.no3;

import java.util.Scanner;

public class PosOrNeg {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter a number: ");
		int n = sc.nextInt();
		if (n > 0)
			System.out.println("Number is positive");
		else
			System.out.println("Number is negative");
	}

}
