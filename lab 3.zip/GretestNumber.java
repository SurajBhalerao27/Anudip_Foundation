/*
 * 8) Write a program to find the max of three numbers.
 * */
package practicals.no3;

import java.util.Scanner;

public class GretestNumber {

	public int gretestNumber(int num1, int num2, int num3) {
		if (num1 > num2 && num1 > num3) {
			return num1;
		} else if (num2 > num1 && num2 > num3) {
			return num2;
		} else {
			return num3;
		}
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter 1st num: ");
		int num1 = sc.nextInt();
		System.out.println("Enter 2st num: ");
		int num2 = sc.nextInt();
		System.out.println("Enter 3st num: ");
		int num3 = sc.nextInt();

		GretestNumber gn = new GretestNumber();
		System.out.println("The gretest number is: " + gn.gretestNumber(num1, num2, num3));
	}

}
