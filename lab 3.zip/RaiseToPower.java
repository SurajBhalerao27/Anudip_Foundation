/*
 * 6) Take two inputs. Eg 3 and 4. Find the value of 3^4 i.e. 3 raised to 4. You cannot use Math.pow() method.
 * */
package practicals.no3;

import java.util.Scanner;

public class RaiseToPower {
	public int raiseToPower(int base, int power) {
		int default_power = 1;
		while (power > 0) {
			default_power = default_power * base;
			power--;
		}
		return default_power;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter base: ");
		int base = sc.nextInt();
		System.out.println("Enter power: ");
		int power = sc.nextInt();

		RaiseToPower r = new RaiseToPower();
		int result = r.raiseToPower(base, power);
		System.out.println(result);
	}

}
