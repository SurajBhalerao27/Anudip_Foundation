/*7) Write a program to find whether a given year is a leap year or not.
 * */
package practicals.no3;

import java.util.Scanner;

public class LeapOrNot {

	public static void main(String[] args) {
		int rem, temp,rev=0;
		while (true) {
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter a year: ");
			int year = sc.nextInt();
			temp = year;
			boolean validYear = true;
//			while (year > 0) {
//				rem = year % 10;
//				year = year / 10;
//				rev = rev * 10 + rem;
//				if (rev > 4) {
//					validYear = false;
//					System.out.println("Enter Valid year !!!");
//					break;
//				}
//			}
			if (validYear) {
				if ((temp % 4 == 0) && (temp % 100 != 0 || temp % 400 == 0)) {
					System.out.println(temp + " is Leap Year ");
				} else {
					System.out.println(temp + " Not Leap Year ");
				}
				System.out.println("______________________________");
			}
		}
	}
}
