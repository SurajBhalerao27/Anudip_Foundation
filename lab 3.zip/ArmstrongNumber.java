/*5) Check if a given number is an armstrong number.
 *
 *Armstrong number is a number that is equal to the sum of cubes of its digits. 
 *For example 0, 1, 153, 370, 371 and 407 are the Armstrong numbers.
 * 
 * */
package practicals.no3;

import java.util.Scanner;

class Armstrong {
	public int temp, sum = 0, rem;

	public void armStrong(int number) {
		temp = number;
		while (number > 0) {
			rem = number % 10;
			number = number / 10;
			sum = sum + (rem * rem * rem);
		}
		if (sum == temp)
			System.out.println("< " + temp + " > is a armstrong number");
		else
			System.out.println("< " + temp + " > is not armstrong number");
	}
}

public class ArmstrongNumber {

	public static void main(String[] args) {
		int c = 1;
		while (true) {
			System.out.println("Enter a Number: ");
			Scanner sc = new Scanner(System.in);
			int number = sc.nextInt();
			Armstrong am = new Armstrong();
			am.armStrong(number);
			c++;
			if (c > 3)
				break;
		}
	}

}
