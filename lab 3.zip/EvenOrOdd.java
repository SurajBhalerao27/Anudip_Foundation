/*
 * 1) Write a program to take a number from user. Check if the number is even or odd.
 * */
package practicals.no3;

import java.util.Scanner;

public class EvenOrOdd {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number: ");
		int num = sc.nextInt();
		if (num % 2 == 0)
			System.out.println("Even");
		else
			System.out.println("Odd");
	}
}