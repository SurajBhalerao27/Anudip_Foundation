package practicals.no3;

import java.util.Scanner;

public class VovelOrConsonant {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter A Character: ");
		char ch = sc.next().charAt(0);
//		int character = Integer.parseInt(ch);
		ch = Character.toUpperCase(ch);
		if (ch == 65 || ch == 69 || ch == 73 || ch == 79 || ch == 85) {
			System.out.println(ch + " is a Vovel");
		} else {
			System.out.println(ch + " is a Consonant");
		}
	}

}
