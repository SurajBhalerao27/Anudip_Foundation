/*
 * 10) Write a program switch for taking a user input for an icecream 
 * flavour and print the cost of that icecream.
 * */
package practicals.no3;

import java.util.Scanner;

public class IceCreamCost {
	public static void main(String[] args) {
		float total_cost = 0.0f;
		Scanner sc = new Scanner(System.in);

		while (true) {
			System.out.println("Enter your choice for ice-cream from 1-4 and ' 0 ' to total: ");
			int input = sc.nextInt();

			float rupees = 0.0f;

			switch (input) {
			case 1:
				System.out.println("You selected * Rocky Road *");
				rupees = 30.48f;
				break;
			case 2:
				System.out.println("You selected * Butter pecan *");
				rupees = 56.5f;
				break;
			case 3:
				System.out.println("You selected * Pistachio *");
				rupees = 45.5f;
				break;
			case 4:
				System.out.println("You selected * Neapolitan *");
				rupees = 56.49f;
				break;
			case 0:
				System.out.println("calculating the total...");
				System.out.println("Total Cost= " + total_cost + " Rs");
				return;
			default:
				System.out.println("Invalid choice. Please select a valid flavor.");
				continue;
			}
			total_cost += rupees;
		}
	}
}
