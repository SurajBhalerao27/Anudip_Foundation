/*4)  Create a Car class with instance variables carId, engineType, color, brand. Create toString in this class. Write the need and use of toString method.
*/
package lab5;

class Car {
	int carID;
	String engineType, color, brand;

	/*
	 * We write toString() method because, we need well representation of the
	 * instances of the class, if we don't use toString() method it might give's us
	 * awkward string representations which are memory addresses of the object.
	 */
	@Override
	public String toString() {
		return "Car [carID=" + carID + ", engineType=" + engineType + ", color=" + color + ", brand=" + brand + "]";
	}
}

public class Fourth {
	public static void main(String[] args) {

	}
}
