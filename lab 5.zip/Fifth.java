/*Write a program to show if main method can be overloaded or not*/
package lab5;

public class Fifth {
	/*
	 * as the main is the method so we can easily overload it with various arguments
	 * but here is a catch
	 * 
	 * the java program enters or start through main method which have (String []
	 * args) string type arguments.
	 */
	public static void main(String[] args) {
		System.out.println("Here is the main method");
		Fifth f = new Fifth();
		f.main(50, 60.00);
		f.main(78.8f);

		// here we also called the main method itself.
		f.main(null);
	}

	public static void main(int a, double b) {
		System.out.println("main with int and double");
	}

	public static void main(float x) {
		System.out.println("main with float type of array");
	}
}
