/*Show constructor overloading in Vehicle class*/
package lab5;

class vehicle {
	private String nameOfCar, model;
	private int manufacturingYear;

	public vehicle() {
	}

	public vehicle(String nameOfCar, String model) {
		super();
		this.nameOfCar = nameOfCar;
		this.model = model;
	}

	public vehicle(String nameOfCar, String model, int manufacturingYear) {
		super();
		this.nameOfCar = nameOfCar;
		this.model = model;
		this.manufacturingYear = manufacturingYear;
	}

	public String getNameOfCar() {
		return nameOfCar;
	}

	public String getModel() {
		return model;
	}

	public int getManufacturingYear() {
		return manufacturingYear;
	}

	public void display() {
		System.out.println("Name of car: " + nameOfCar + "\nName of model: " + model + "\nYear of manufacturing: "
				+ manufacturingYear);
	}

}

public class Second {
	public static void main(String[] args) {
		vehicle v1 = new vehicle("Fortuner", "Toyota"), v2 = new vehicle("Thar", "Mahindra", 2020);

		v1.display();
		System.out.println("**********************************");
		v2.display();
	}
}
