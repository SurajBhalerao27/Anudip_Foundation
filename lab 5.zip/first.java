/*Create a Trainer class having instance variables:- trainerId, trainerName, subject, officeLocation.
Make getter setters in this class.*/
package lab5;

class Trainer {
	int trainerID;
	String trainerName, Subject, officeLocation;

	public int getTrainerID() {
		return trainerID;
	}

	public void setTrainerID(int trainerID) {
		this.trainerID = trainerID;
	}

	public String getTrainerName() {
		return trainerName;
	}

	public void setTrainerName(String trainerName) {
		this.trainerName = trainerName;
	}

	public String getSubject() {
		return Subject;
	}

	public void setSubject(String subject) {
		Subject = subject;
	}

	public String getOfficeLocation() {
		return officeLocation;
	}

	@Override
	public String toString() {
		return "Tainer [trainerID=" + trainerID + ", trainerName=" + trainerName + ", Subject=" + Subject
				+ ", officeLocation=" + officeLocation + "]";
	}

	public void setOfficeLocation(String officeLocation) {
		this.officeLocation = officeLocation;
	}

}

public class first {
	public static void main(String[] args) {
		Trainer trainer = new Trainer();
	}
}
