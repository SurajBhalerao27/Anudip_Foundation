/*
    Q 5) 
       Write a program to create method which will ask for the name of the student.
 	   Then the method should return the message " Hello -------------- . Welcome to this java session ".
 
 	   This message should be printed on console
 */
package practice;

public class MethodCalling {

	public void MethodCalling(String name) {
		System.out.println("Hello " + name + ", Welcome to this java session");
	}

	public static void main(String[] args) {
		MethodCalling m = new MethodCalling();
		m.MethodCalling("Suraj Bhalerao");
	}

}
