/*
  Q 6) Write a program to calculate the percentage of a student based on the marks
		he or she has received out of 500
		Take user input for the total marks received by student.
 */

package practice;

import java.util.Scanner;

public class Percentage {

	public double cal(double p) {
		if (p <= 500)
			return ((p / 500) * 100);
		else
			System.out.println("Please Enter Valid Marks !");
		return 0;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Total marks out of '500': ");
		double marks = sc.nextInt();

		Percentage p = new Percentage();
//		double total = p.cal(marks);
		System.out.println(p.cal(marks) + "%");
	}

}