/*
 * Q 4) Write a program to call static variable from some other class.
 */
package practice;

class StaticVariable {
	static int a = 40, b = 50;
}

public class StaticVariable2 {

	public static void main(String[] args) {

		StaticVariable s = new StaticVariable();
		System.out.println("Variable a: " + s.a);
		System.out.println("Variable b: " + s.b);
	}

}