/*
 Q 2) Write a program to demonstrate local variable.Print the local variable on console.
 */
package anudip.day2;

public class LocalVariables {

	public static void main(String[] args) {
		int a = 100; // This is the local variable which is whithin the same class only
		System.out.println("This is the local variable: "+a);
	}
}
