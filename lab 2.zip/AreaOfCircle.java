/*
 * Q 1) Create a method which will calculate the area of circle. Take the radius from user. 3.14 * r *r
 * 
 */
package practice;

import java.util.Scanner;

public class AreaOfCircle {
	public double Area(double radius) {
		if (radius > 0)
			return 3.14 * radius * radius;
		else
			System.out.println("Please Enter Valid Radius in (CM)");
		return 0;
	}

	public static void main(String a[]) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the radius of circle(in cm): ");
		double radius = sc.nextDouble();

		AreaOfCircle a1 = new AreaOfCircle();
//		double result = a1.Area(radius);
		System.out.println(a1.Area(radius) + " sq.cm");
	}

}