console.log("For Loop:");
for (let i = 1; i <= 5; i++) {
  console.log(i);
}

console.log("\nFor-In Loop:");
const person = { name: "John", age: 30, city: "New York" };
for (let key in person) {
  console.log(`${key}: ${person[key]}`);
}

console.log("\nWhile Loop:");
let counter = 1;
while (counter <= 5) {
  console.log(counter);
  counter++;
}

console.log("\nDo-While Loop:");
let num = 1;
do {
  console.log(num);
  num++;
} while (num <= 5);
