function checkVotingAge(age) {
  if (age >= 18) {
    console.log("You are eligible to vote!");
  } else {
    console.log("Sorry, you are not eligible to vote yet.");
  }
}
let userAge = 20;
checkVotingAge(userAge);
