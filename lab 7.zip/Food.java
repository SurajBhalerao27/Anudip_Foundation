package lab;

// Food pojo Class
public class Food {
	Integer foodId;
	String foodName;
	String foodType;
	Float price;
	Float rating;

	public Food() {
		super();
	}

	public Food(Integer foodId, String foodName, String foodType, Float price, Float rating) {
		super();
		this.foodId = foodId;
		this.foodName = foodName;
		this.foodType = foodType;
		this.price = price;
		this.rating = rating;
	}

	public Integer getFoodId() {
		return foodId;
	}

	public void setFoodId(Integer foodId) {
		this.foodId = foodId;
	}

	public String getFoodName() {
		return foodName;
	}

	public void setFoodName(String foodName) {
		this.foodName = foodName;
	}

	public String getFoodType() {
		return foodType;
	}

	public void setFoodType(String foodType) {
		this.foodType = foodType;
	}

	public Float getPrice() {
		return price;
	}

	public void setPrice(Float price) {
		this.price = price;
	}

	public Float getRating() {
		return rating;
	}

	public void setRating(Float rating) {
		this.rating = rating;
	}

	public int compareTo(Food f) {
		return Float.compare(this.price, f.price);
	}

	@Override
	public String toString() {
		return "Food ID= " + foodId + ", Food Name= " + foodName + ", Food Type= " + foodType + ", Price(Rs)= " + price
				+ ", Ratings Out of 5 is= " + rating + "\n";
	}

}
