package lab;

import java.util.ArrayList;

public class RmDuplicates {
	public static void main(String[] args) {

		ArrayList<String> bayBlade = new ArrayList<>();

		bayBlade.add("Sagitario");
		bayBlade.add("Pegasus");
		bayBlade.add("Aquario");
		bayBlade.add("Sagitario");
		bayBlade.add("Libra");
		bayBlade.add("Lion");
		bayBlade.add("Aquario");
		bayBlade.add("Libra");
		bayBlade.add("Pegasus");
		bayBlade.add("Lion");

		System.out.println("Original List: " + bayBlade);

		ArrayList<String> uniqBayBlade = new ArrayList<>();

		for (String s : bayBlade) {
			boolean isDuplicate = false;

			for (String uniq : uniqBayBlade) {
				if (s.equals(uniq)) {
					isDuplicate = true;
					break;
				}
			}
			if (!isDuplicate)
				uniqBayBlade.add(s);
		}
		System.out.println("\nAfter Removing Duplicates: " + uniqBayBlade);
	}

}
