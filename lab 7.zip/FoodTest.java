package lab;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class FoodTest {
	public static void main(String[] args) {
		ArrayList<Food> foodCart = new ArrayList<>();

		// Adding food objects to foodCart
		foodCart.add(new Food(10, "Gulab jam", "Veg", 60.40f, 4.5f));
		foodCart.add(new Food(2, "Alu-Wadi", "Veg", 50.30f, 5.0f));
		foodCart.add(new Food(4, "Thalipith", "Veg", 80.80f, 3.5f));
		foodCart.add(new Food(25, "Puram Poli", "Veg", 20.45f, 5.0f));

		// Using lambda expression
		Collections.sort(foodCart, (food1, food2) -> Float.compare(food1.getPrice(), food2.getPrice()));

		// Using compareTo()
		// Collections.sort(foodCart); // This give error ??

		// For printing the cart of food
		for (Food food : foodCart) {
			System.out.println(food);
		}
	}
}
