package lab;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;

public class Sorting {
	public static void main(String[] args) {
		HashSet<String> unOrder = new HashSet<>();
		unOrder.add("Banana");
		unOrder.add("Yellow");
		unOrder.add("Lack");
		unOrder.add("Amazon");
		unOrder.add("Aramco");
		unOrder.add("Canvas");
		ArrayList<String> order = new ArrayList<>(unOrder);
		Collections.sort(order);
		System.out.println("By Alphabetical Order: " + order);
	}
}
