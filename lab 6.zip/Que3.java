package lab6;

class Animal {
	String name;

	Animal(String name) {
		this.name = name;
	}

	void speak() {
		System.out.println(name + " makes a sound");
	}
}

class Dog extends Animal {
	Dog(String name) {
		super(name);
	}

	@Override
	void speak() {
		System.out.println(name + " says Woof!");
	}
}

class GoldenRetriever extends Dog {
	GoldenRetriever(String name) {
		super(name);
	}

	void fetch() {
		System.out.println(name + " is fetching a ball.");
	}
}

public class Que3 {
	public static void main(String[] args) {
		Animal animal = new Animal("All Dogs");
		Dog dog = new Dog("Moti");
		GoldenRetriever goldenRetriever = new GoldenRetriever("Tommy");

		System.out.println(animal.name); 
		System.out.println(dog.name);
		dog.speak();
		goldenRetriever.speak();
		goldenRetriever.fetch(); 
	}
}