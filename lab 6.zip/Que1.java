package lab6;
// this is the example of compilable class
public class Que1 {
	private String message;

	public Que1(String message) {
		this.message = message;
	}

	public void printMessage() {
		System.out.println("Message: " + message);
	}
}
