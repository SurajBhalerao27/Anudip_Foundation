package lab6;

// this is the example of executable class
public class Que2 {
	public static void main(String[] args) {
		Que1 q = new Que1("Hello! Compilable Class->(Que1). I'm Executable class->(Que2)");
		q.printMessage();
	}
}

/*

 2) What is the difference between Compilable class and Executable class.

 +-----------------------------------------------------+------------------------------------------------------------+
 |	Compilable Class                                   |  Executable Class                                          |
 +-----------------------------------------------------+------------------------------------------------------------+
 |	Provide reusable code components.	               |  Serve as the entry point for running a program.           |
 |	May or may not contain a main method.	           |  Must contain a main method for execution.                 |
 |	Not executed directly; used within other classes.  |  Executed directly to initiate the program.                |
 |	Building block for creating executable programs.   |  Initiates program execution and performs specific tasks.  |
 |	Utility classes, libraries, data structures.	   |  Main class of a Java application or program.              |
 +-----------------------------------------------------+------------------------------------------------------------+

 */
