/*
 * 5) Explain with programs how the access specifiers can be changed in overridden methods.
*/
package lab6;

class Parent {
    protected void display() {
        System.out.println("This is a protected method in Parent class.");
    }
}

class Child extends Parent {
    public void display() { 
    	// this have more accesibility than parent's protected display() method.
        System.out.println("This is a public method in Child class.");
    }
}

public class Que5 {
    public static void main(String[] args) {
        Child child = new Child(); 
        Parent parent = new Parent();
        child.display();
        parent.display();   
    }
}
